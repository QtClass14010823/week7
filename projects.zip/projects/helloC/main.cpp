/* Hello World C Program */

#include <stdio.h>

int main()
{
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("Hello World!\n");
	printf("hELlo World!\n");
	return 0;
}
