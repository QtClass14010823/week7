#include <QTextStream>

int main() {
	QTextStream(stdout) << "Hello, world!" << endl;
	return 0;
}
