#include<stdio.h>
#include<stdlib.h>
#include"insertion_sort.h"
 
int ascending(int a, int b)
{
    return a > b;
}
 
int descending(int a, int b)
{
    return a < b;
}
 
int even_first(int a, int b)
{
  if ((a % 2 == 0) && (b % 2 != 0))
    return 0;
  else if ((a % 2 != 0) && (b % 2 == 0))
    return 1;
  else
    return (a > b);
}
 
int odd_first(int a, int b)
{
  if ((a % 2 != 0) && (b % 2 == 0))
    return 0;
  else if ((a % 2 == 0) && (b % 2 != 0))
    return 1;
  else
    return (a > b);
}
 
int main(void)
{
    int i;
    int choice;
    int array[10] = {22,66,55,11,99,33,44,77,88,0};
    printf("ascending 1: descending 2: even_first 3: odd_first 4: quit 5\n");
    printf("enter your choice = ");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
            insertion_sort(array,10, ascending);
            break;
        case 2:
            insertion_sort(array,10, descending);
            break;
         case 3:
            insertion_sort(array,10, even_first);
            break;
        case 4:
            insertion_sort(array,10, odd_first);
            break;
        case 5:
            exit(0);
        default:
            printf("no such option\n");
    }
 
    printf("after insertion_sort\n");
    for(i=0;i<10;i++)
        printf("%d\t", array[i]);
    printf("\n");
     return 0;
}
